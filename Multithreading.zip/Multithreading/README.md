
details: https://docs.google.com/document/d/14kjXmxR2xijkt1ie0UOLleGofBOhvdN6i9_A8iLpyhA/edit