public class Main {
    public static void main(String[] args) {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                System.out.println("Current thread is: "+Thread.currentThread().getName());
                System.out.println("Current thread priority: "+Thread.currentThread().getPriority());

                //suppose we do an error here
                //throw new RuntimeException("Unhandled Exception");
            }
        });

        System.out.println("We are now in: "+Thread.currentThread().getName()+" .Before starting a new thread");
        t.setName("New Renamed Thread");
        t.setPriority(Thread.MAX_PRIORITY);

        //we can catch unhandled exception in a thread
        t.setUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            @Override
            public void uncaughtException(Thread thread, Throwable throwable) {
                System.out.println("An error happened in the thread: "+t.getName()+". Error is: "+throwable.getMessage());
            }
        });


        t.start();

        System.out.println("We are now in: "+Thread.currentThread().getName()+" .After starting a new thread");

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
