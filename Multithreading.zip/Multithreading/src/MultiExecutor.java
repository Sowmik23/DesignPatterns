import java.util.ArrayList;
import java.util.List;

public class MultiExecutor {

    // Add any necessary member variables here
    List<Runnable> tasks = new ArrayList<>();

    public MultiExecutor(List<Runnable> tasks) {
        // Complete your code here
        this.tasks = tasks;
    }

    /**
     * Starts and executes all the tasks concurrently
     */
    public void executeAll(){
        // complete your code here
        List<Thread> threadList = new ArrayList<>(tasks.size());

        for(Runnable t : tasks){
            Thread thread = new Thread(t);
            threadList.add(thread);
        }

        for(Thread t : threadList){
            t.start();
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {

        List<Runnable> lst = new ArrayList<>();
        lst.add(new NewThread());
        lst.add(new NewThread1());
        lst.add(new NewThread2());
        lst.add(new NewThread3());

        MultiExecutor executor = new MultiExecutor(lst);
        executor.executeAll();
    }

    public static class NewThread implements Runnable {

        @Override
        public void run() {
            Thread.currentThread().setPriority(Thread.MIN_PRIORITY);
            System.out.println("NewThread is running....");
        }
    }
    public static class NewThread1 implements Runnable {

        @Override
        public void run() {
            System.out.println("NewThread1 is running...");
        }
    }
    public static class NewThread2 implements Runnable {

        @Override
        public void run() {
            Thread.currentThread().setPriority(Thread.MAX_PRIORITY);
            System.out.println("NewThread2 is running...");
        }
    }
    public static class NewThread3 implements Runnable {

        @Override
        public void run() {
            System.out.println("NewThread3 is running...");
        }
    }
}