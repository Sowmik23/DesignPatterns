public class ExtendingThreadClass {
    public static void main(String[] args) {
        Thread t = new NewThread();

        System.out.println("Main thread is running...:"+Thread.currentThread().getName());
        System.out.println("Main thread id is: "+Thread.currentThread().getId());
        System.out.println("Before starting new thread");

        t.start();
        System.out.println("After starting new thread");
    }

    private static class NewThread extends Thread {
        @Override
        public void run(){
            System.out.println("current thread is: "+this.getName());
            System.out.println("id: "+this.getId());
        }
    }
}
